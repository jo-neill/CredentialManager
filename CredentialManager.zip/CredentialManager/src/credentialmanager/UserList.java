/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.ArrayList;

/**
 *
 * @author hmk5180
 */
public class UserList {
    private ArrayList<User> listOfUsers = null;
    
    // Creating some test users
    public UserList() {
        listOfUsers = new ArrayList();
        for (int i = 0; i < 5; i++) {
            String testUsername = "user" + i;
            char[] testPassword = {'p', 'a', 's', 's'};
            User newUser = new User(testUsername, testPassword);
            listOfUsers.add(newUser);
        }
    }
    
    public ArrayList<User> getListOfUsers() {
        return listOfUsers;
    }
    
    public boolean authenticate(String username, char[] password) {
        boolean authenticated = false;
        for (int i = 0; i < listOfUsers.size(); i++) {
            if (listOfUsers.get(i).authenticate(username, password)) {
                authenticated = true;
            }
        }
        return authenticated;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.Arrays;

/**
 *
 * @author hmk5180
 */
public class User {
    private String username = "";
    private char[] password = null;
    
    public User(String newUsername, char[] newPassword) {
        username = newUsername;
        password = newPassword;
    }
    
    public String getUsername() {
        return username;
    }
    
    public char[] getPassword() {
        return password;
    }
    
    public boolean authenticate(String username, char[] password) {
        boolean authenticated = false;
        if (this.getUsername().equals(username) && Arrays.equals(this.getPassword(), password)) {
            authenticated = true;
        }
        return authenticated;
    }
}

package credentialmanager;

//Stores and grants access to some credentials of the users
public class User {
    private String username = "";
    private char[] password = {};
    
    public User(String newUsername, char[] newPassword) {
        username = newUsername;
        password = newPassword;
    }
    
    public String getUsername() {
        return username;
    }
    
    public char[] getPassword() {
        return password;
    }
    
    /*
    Will add field failedTries, method addFieldTry(), and another method in LoginCtrl that keeps track of failed tries to sign into a username
    and only allows a certain amount of failed tries over the course of a period of time
    */
    
}

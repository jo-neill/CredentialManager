/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

/**
 *
 * @author hmk5180
 */
public class NavigationCtrl {
    public NavigationCtrl() {
        // I set the app to terminate for now but it should navigate users to somewhere else
        System.exit(0);
    }
}

package credentialmanager;

public class AccountList {
    public AccountList(){
    
    }
}

package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class RegisterMenu extends JFrame implements ActionListener{
    
    private final JFrame frame;
    private final JPanel panel1, panel2, panel3, panel4;
    private final JLabel label1, label2, label3;
    private final JButton btnSubmit, btnClose;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    
    public RegisterMenu(){
        
        frame = new JFrame("Register");
        frame.setLayout(new GridLayout(4,1));
        
        panel1 = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        
        label1 = new JLabel("Username:");
        label2 = new JLabel("Password:");
        label3 = new JLabel("Confirm Password:");
        
        usernameField = new JTextField();
        usernameField.setColumns(10);
        passwordField = new JPasswordField();
        passwordField.setColumns(10);
        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setColumns(10);
        
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        panel1.add(label1); 
        panel1.add(usernameField);
        panel2.add(label2); 
        panel2.add(passwordField);
        panel3.add(label3); 
        panel3.add(confirmPasswordField);
        panel4.add(btnSubmit); 
        panel4.add(btnClose);
        
        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);
        frame.add(panel4);
        frame.setSize(400, 300);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        
        if(arg.equals("Submit")){
            
            String usr = usernameField.getText();
            String pass = passwordField.getText();
            String pass_cfm = confirmPasswordField.getText();
            if(pass.equals(pass_cfm)){
                RegisterCtrl reg = new RegisterCtrl(usr, pass);
                this.frame.setVisible(false);
                new AppMenu();
            }
            else{
                JOptionPane.showMessageDialog(null, "Your password and password confirmation do not match!\nPlease try again.");
                this.frame.setVisible(false);
                new RegisterMenu();
            }
        }
        
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

package credentialmanager;

public class RegisterCtrl extends UserList{

    public RegisterCtrl(String username, String password) {
        addNewUser(username, password);
    }

    public void addNewUser(String username, String password) {
        char[] passArray = new char[password.length()];
        
        for(int i = 0; i < password.length(); i++){
            passArray[i] = password.charAt(i);
        }

        User user = new User(username, passArray);
        addUser(user);
   
    }
        
}

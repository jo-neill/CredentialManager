package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AccountView extends JFrame implements ActionListener{
    private JFrame frame;
    private JPanel panel1, panel2, panel3, panel4, panel5, panel6, panel7, panel8;
    private JLabel label1, usernameLabel, accountLabel, passwordLabel, rePasswordLabel;
    private JTextField usernameField, accountField;
    private JPasswordField passwordField, rePasswordField;
    private JButton submit, btnClose;
    
    private AccountCtrl acctCtrl = null;
    
    public AccountView(AccountCtrl acctCtrl){
        this.acctCtrl = acctCtrl;
        
        frame = new JFrame("Credential Manager");
        frame.setLayout(new GridLayout(8,1));
        panel1 = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        panel5 = new JPanel(new FlowLayout());
        panel6 = new JPanel(new FlowLayout());
        panel7 = new JPanel(new FlowLayout());
        panel8 = new JPanel(new FlowLayout());
        
        label1 = new JLabel("Add a new account.");
        
        accountLabel = new JLabel("Account title:");
        accountField = new JTextField();
        
        usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        
        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        
        rePasswordLabel = new JLabel("Re-enter password:");
        rePasswordField = new JPasswordField();
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        accountField.setColumns(16);
        usernameField.setColumns(10);
        passwordField.setColumns(10);
        rePasswordField.setColumns(10);
        
        panel1.add(accountLabel);
        panel1.add(accountField);
        panel2.add(usernameLabel);
        panel2.add(usernameField);
        panel3.add(passwordLabel);
        panel3.add(passwordField);
        panel4.add(rePasswordLabel);
        panel4.add(rePasswordField);
        panel5.add(submit);
        panel5.add(btnClose);
        panel6.add(label1);
        
        frame.add(panel7);
        frame.add(panel6);
        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);
        frame.add(panel4);
        frame.add(panel5);
        frame.add(panel8);
        frame.setSize(400, 300);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.getRootPane().setDefaultButton(submit);
    }
    
    public JFrame getFrame() {
        return frame;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            if(Arrays.equals(this.passwordField.getPassword(),this.rePasswordField.getPassword()) && !this.accountField.getText().equals("") && !this.usernameField.getText().equals("") && this.passwordField.getPassword().length != 0 && this.rePasswordField.getPassword().length != 0){
                String account = this.accountField.getText();
                String username = this.usernameField.getText();
                char[] password = this.passwordField.getPassword();
                Account newAccount = new Account(account, username, password);
                acctCtrl.setAccount(newAccount);
                this.frame.setVisible(false);
                MainMenu newMain = new MainMenu();
            }
            else if(!Arrays.equals(this.passwordField.getPassword(),this.rePasswordField.getPassword())){
                JOptionPane.showMessageDialog(null, "Your passwords do not match, try again!");
            }
            else{
                JOptionPane.showMessageDialog(null, "Please fill in all fields!");
            }
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}
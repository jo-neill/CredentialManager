/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

/**
 *
 * @author hmk5180
 */
public class LoginCtrl {
    private LoginMenu theLoginMenu;
    private UserList theUserList;
    
    public LoginCtrl() {
        theUserList = new UserList();
        theLoginMenu = new LoginMenu(this);
    }
    
    public boolean requestAuthenticate(String username, char[] password) {
        boolean authenticated = false;
        
        if (theUserList.authenticate(username, password)) {
            System.out.println("Authenticated user");
            NavigationCtrl theNavigationCtrl = new NavigationCtrl();
            authenticated = true;            
        }
        
        return authenticated;
    }
}

package credentialmanager;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class AccountCtrl {

    private AccountView accountView = null;
    private Account account = null;

    public AccountCtrl() throws IOException {
        this.accountView = new AccountView(this);
        writeToFile("/credentialmanager/Accounts.rtf", account);
    }

    public void setAccount(Account acct) {
        account = acct;
    }

    public static void writeToFile(String fileName, Account acct) throws IOException {
        try {
            String encryptedAcct= acct.toString();
            Cipher.encode(encryptedAcct, 13);
            FileOutputStream fileOut = new FileOutputStream("/credentialmanager/Accounts.rtf");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(encryptedAcct);
            out.close();
            fileOut.close();
            System.out.printf("Saved in /credentialmanager/Accounts.rtf");
        } catch (IOException i) {
            System.out.println("IO Exception in AccountCtrl writeToFile(...)");
        }

    }
    
    public void readFromFile(String fileName){
        ArrayList<String> acctList = null;
        try {
         FileInputStream fileIn = new FileInputStream("/credentialmanager/Accounts.rtf");
         ObjectInputStream in = new ObjectInputStream(fileIn);
         acctList = (ArrayList<String>) in.readObject();
         for(int i=0; i<acctList.size(); i++){
             acctList.set(i, Cipher.decode(acctList.get(i), 13));
         }
         in.close();
         fileIn.close();
      }catch(IOException i) {
         System.out.println("IO Exception in AccountCtrl readFromFile");
      }catch(ClassNotFoundException c) {
         System.out.println("Class not found");
      }
    }
}
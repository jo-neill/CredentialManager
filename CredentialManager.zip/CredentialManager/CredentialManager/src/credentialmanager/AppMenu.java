package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//GUI for the main menu
public class AppMenu extends JFrame implements ActionListener{

    private final JFrame frame;
    private final JPanel panel1, emptyPanel, emptyPanel2, welcomePanel;
    private final JLabel welcomeLabel, emptyLabel;
    private final JButton btnOpenLogin, btnClose;

    public AppMenu(){
        frame = new JFrame("Credential Manager");
        frame.setLayout(new GridLayout(4, 1));
        panel1 = new JPanel(new FlowLayout());
        emptyPanel = new JPanel(new FlowLayout());
        emptyPanel2 = new JPanel(new FlowLayout());
        welcomePanel = new JPanel(new FlowLayout());
        
        welcomeLabel = new JLabel("Welcome to Credential Manager!");
        emptyLabel = new JLabel("");
        
        btnOpenLogin = new JButton("Login");
        btnOpenLogin.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        emptyPanel.add(emptyLabel);
        welcomePanel.add(welcomeLabel);
        emptyPanel2.add(emptyLabel);
        panel1.add(btnOpenLogin);
        panel1.add(btnClose);
        
        frame.add(emptyPanel);
        frame.add(welcomePanel);
        frame.add(panel1);
        frame.add(emptyPanel2);
        frame.setSize(300, 200);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setVisible(true);
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Login")){
            LoginCtrl loginCtrl = new LoginCtrl();
            this.frame.setVisible(false);
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author hmk5180
 */
public class SearcherView extends JFrame implements ActionListener{
    private JFrame frame;
    private JLabel label;
    private JLabel label2;
    private JTextField keywordField;
    private JButton submit;
    private JButton btnClose;
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    
    private Searcher search = null;
    
    public SearcherView(Searcher search) {
        this.search = search;
        
        frame = new JFrame("Credential Manager");
        frame.setLayout(new GridLayout(5,1));
        panel = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        
        label = new JLabel("<Search for Account>");
        label2 = new JLabel("Enter a keyword:");
        keywordField = new JTextField();
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        keywordField.setColumns(10);
        
        panel.add(label);
        panel2.add(label2);
        panel2.add(keywordField);
        panel3.add(submit);
        panel3.add(btnClose);
        
        frame.add(panel4);
        frame.add(panel);
        frame.add(panel2);
        frame.add(panel3);
        frame.setSize(450, 200);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.getRootPane().setDefaultButton(submit);
    }
    
    public JFrame getFrame() {
        return frame;
    }
    
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            String keyword = keywordField.getText();
            this.frame.setVisible(false);
            String result = search.getAccountName(keyword);
            JOptionPane.showMessageDialog(null, result);
            MainMenu newMain = new MainMenu();
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

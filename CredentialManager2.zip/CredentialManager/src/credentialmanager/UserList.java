package credentialmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;

//UserList creates a List of users
public class UserList {

    private List<User> listOfUsers;
    User nate;

    public UserList(ArrayList<User> listOfUsers) {
        this.listOfUsers = listOfUsers;
    }

    public UserList() {
        listOfUsers = new ArrayList();
        createTestUsers();
        addTestAccounts(nate);
    }

    //Creates test users until we have real ones
    private void createTestUsers() {
        char[] testPassword = {'p', 'a', 's', 's', 'w', 'o', 'r', 'd'};
        User joe = new User("joe", testPassword);
        addUser(joe);
        User hyunsook = new User("hyunsook", testPassword);
        addUser(hyunsook);
        User zach = new User("zach", testPassword);
        addUser(zach);
        nate = new User("nate", testPassword);
        addUser(nate);
    }

    private void addTestAccounts(User user) {

        String testPass = "pass";
        char[] pass = testPass.toCharArray();
        Account test1 = new Account("gmail", "nate", pass);
        user.addAccount(test1);
        Account test2 = new Account("hotmail", "joe", pass);
        user.addAccount(test2);
        Account test3 = new Account("yahoo", "kate", pass);
        user.addAccount(test3);
        Account test4 = new Account("yahoo", "steve", pass);
        user.addAccount(test4);
        Account test5 = new Account("yahoo", "zach", pass);
        user.addAccount(test5);
        Account test6 = new Account("yahoo", "hyunsook", pass);
        user.addAccount(test6);
        Account test7 = new Account("yahoo", "rob", pass);
        user.addAccount(test7);
        Account test8 = new Account("yahoo", "jane", pass);
        user.addAccount(test8);
        Account test9 = new Account("yahoo", "emma", pass);
        user.addAccount(test9);
        Account test10 = new Account("yahoo", "ray", pass);
        user.addAccount(test10);     

    }

    public List<User> getListOfUsers() {
        return listOfUsers;
    }

    public void addUser(User newUser) {
        listOfUsers.add(newUser);
    }
    
    //------------------------------------------------------
    
    void addUserFile(User usr) throws FileNotFoundException, UnsupportedEncodingException{
    
        String fileName = usr.getUsername()+ ".txt";
        
        File f = new File(usr.getUsername()+ ".txt");
        boolean exists = f.exists();
        
        if(!exists){
        try (PrintWriter writer = new PrintWriter(fileName, "UTF-8")) {
            writer.println(usr.getUsername());
            writer.println(String.valueOf(usr.getPassword()));
            writer.close();
        }
        }
        else{
            JOptionPane.showMessageDialog(null, "That username already exists. Please try again.");
        }
    }
    
    
    /*void deleteFile(String usr){
        String fileName = usr.getUsername()+ ".txt";
        try{
        
    	File file = new File(fileName + ".txt");

    	if(file.delete()){
    		JOptionPane.showMessageDialog(null, "Delete succesfull.");
                }
                else{
    		JOptionPane.showMessageDialog(null, "Delete unsuccesfull :(");
    		}
    	}catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong :(");
    	}
        
    }*/
}

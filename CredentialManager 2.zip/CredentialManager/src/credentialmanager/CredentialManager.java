package credentialmanager;

//Begins the program by creating the main menu
public class CredentialManager {

    public static void main(String[] args) {
        new AppMenu();
    }
}

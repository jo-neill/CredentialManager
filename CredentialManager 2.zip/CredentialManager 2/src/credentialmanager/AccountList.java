package credentialmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class AccountList {
    private ArrayList<Account> listOfAccounts = null;
    private String loggedIn = LoginCtrl.currentUser;
    
    public AccountList() throws FileNotFoundException {
        listOfAccounts = new ArrayList();
        generateAccounts(loggedIn);
    }
    
    private void generateAccounts(String loggedIn) throws FileNotFoundException {
        String fileName = loggedIn + ".txt";
        File file = new File(fileName);
        Scanner reader = new Scanner(file);
    
        Account nextAccount = null;
        reader.nextLine();
        reader.nextLine();
        while(reader.hasNextLine()){
            addAccount(new Account(reader.nextLine(), reader.nextLine(), new String(reader.nextLine())));
        }
        
    }
    
    public void addAccount(Account newAccount){
        listOfAccounts.add(newAccount);
    }
    
    public ArrayList<Account> getListOfAccounts() {
        return listOfAccounts;
    }
}
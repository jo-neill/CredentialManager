package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MainMenu extends JFrame implements ActionListener{
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel label;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton btnGenerate;
    private JButton btnClose;
    private JButton btnSeeAccount;
    private JButton btnAddAccount;
    private JButton btnSearchAccount;
    
    private AddAccountView theAddAccountView = null;
    private AccountListView theAccountListView = null;
    
    public MainMenu(){
        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        
        label = new JLabel("Please choose a feature.");
        
        btnGenerate = new JButton("Generate Password");
        btnGenerate.addActionListener(this);
        btnSeeAccount = new JButton("See My Accounts");
        btnSeeAccount.addActionListener(this);
        btnAddAccount = new JButton("Add Account");
        btnAddAccount.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnSearchAccount = new JButton("Search Account");
        btnSearchAccount.addActionListener(this);
        
        panel.add(label);
        panel3.add(btnGenerate);
        panel3.add(btnSeeAccount);
        panel3.add(btnAddAccount);
        panel3.add(btnSearchAccount);
        panel3.add(btnClose);
        
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.setSize(700, 200);
        this.setTitle("Credential Manager");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Generate Password")){
            Generator gen = new Generator();
            this.setVisible(false);
        }
        else if(arg.equals("Add Account")){
            this.setVisible(false);
            try {
                AccountCtrl theAccountCtrl = new AccountCtrl(theAddAccountView);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(arg.equals("Search Account")){
            try {
                Searcher search = new Searcher();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.setVisible(false);
        }
        else if(arg.equals("See My Accounts")) {
            this.setVisible(false);
            try {
                AccountCtrl theAccountCtrl = new AccountCtrl(theAccountListView);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}
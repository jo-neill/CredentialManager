package credentialmanager;

import java.io.FileNotFoundException;
import java.util.List;

public class Searcher {
    private String result = "";
    private List<Account> listOfAccounts;
    private AccountList accountList;
    private SearcherView sView;
    private boolean found = false;
    
    public Searcher() throws FileNotFoundException {
        this.accountList = new AccountList();
        sView = new SearcherView(this);
    }
    
    public String getAccountName(String keyword) {
        int x = accountList.getListOfAccounts().size();
        for (int i = 0; i < x && found == false; i++) {
            if (accountList.getListOfAccounts().get(i).getAccountName().equalsIgnoreCase(keyword)) {
                String accountNameFound = accountList.getListOfAccounts().get(i).getAccountName();
                String usernameFound = accountList.getListOfAccounts().get(i).getUsername();
                String passwordFound = accountList.getListOfAccounts().get(i).getPasswordString();
                
                result = "Account Name: " + accountNameFound + "\n" + "Username: " + usernameFound + "\n" + "Password: " + passwordFound;

                found = true;
            }
            else {
                result = keyword + " is not found.";
            }
        }
        return result;
    }
}

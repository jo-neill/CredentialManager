package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GeneratorView extends JFrame implements ActionListener{
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JLabel label;
    private JLabel numCharsLabel;
    private JTextField numCharsField;
    private JButton submit;
    private JButton btnClose, btnBack;
    
    private Generator gen = null;
    
    public GeneratorView(Generator gen){
        this.gen = gen;

        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();

        label = new JLabel("<Generate Password>");
        numCharsLabel = new JLabel("Enter the desired number of characters in your password:");
        numCharsField = new JTextField();
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnBack = new JButton("Back");
        btnBack.addActionListener(this);
        
        numCharsField.setColumns(5);
        
        panel2.add(label);
        panel.add(numCharsLabel);
        panel.add(numCharsField);
        panel3.add(submit);
        panel3.add(btnBack);
        panel3.add(btnClose);
        
        this.getContentPane().add(panel4, this.getContentPane());
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.getContentPane().add(panel5, this.getContentPane());
        this.setSize(500, 200);
        this.setTitle("Credential Manager");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.getRootPane().setDefaultButton(submit);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            int passwordLength = Integer.parseInt(numCharsField.getText());
            String password = gen.getPassword(passwordLength);
            this.setVisible(false);
            JOptionPane.showMessageDialog(null, "Your newly generated password is " + password);
            MainMenu newMain = new MainMenu();
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
        else if(arg.equals("Back")) {
            this.setVisible(false);
            MainMenu main = new MainMenu();
            main.setVisible(true);
        }
    }
}
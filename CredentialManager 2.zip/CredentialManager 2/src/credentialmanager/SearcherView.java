/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author hmk5180
 */
public class SearcherView extends JFrame implements ActionListener{
    private JLabel label;
    private JLabel label2;
    private JTextField keywordField;
    private JButton submit;
    private JButton btnClose;
    private JButton btnBack;
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    
    private Searcher search = null;
    
    public SearcherView(Searcher search) {
        this.search = search;
        
        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        panel = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        
        label = new JLabel("<Search for Account>");
        label2 = new JLabel("Enter a keyword:");
        keywordField = new JTextField();
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnBack = new JButton("Back");
        btnBack.addActionListener(this);
        
        keywordField.setColumns(10);
        
        panel.add(label);
        panel2.add(label2);
        panel2.add(keywordField);
        panel3.add(submit);
        panel3.add(btnBack);
        panel3.add(btnClose);
        
        this.getContentPane().add(panel4, this.getContentPane());
        this.getContentPane().add(panel, this.getContentPane());
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.setSize(450, 200);
        this.setTitle("Credential Manager");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.getRootPane().setDefaultButton(submit);
    }
    
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            String keyword = keywordField.getText();
            this.setVisible(false);
            String result = search.getAccountName(keyword);
            JOptionPane.showMessageDialog(null, result);
            MainMenu newMain = new MainMenu();
        }
        else if(arg.equals("Back")) {
            this.setVisible(false);
            MainMenu main = new MainMenu();
            main.setVisible(true);
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

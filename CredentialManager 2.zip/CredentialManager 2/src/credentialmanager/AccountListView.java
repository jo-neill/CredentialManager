/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author hmk5180
 */
public class AccountListView extends javax.swing.JFrame implements ActionListener{
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JLabel label;
    private JLabel label2;
    private JButton btnClose;
    private JButton btnBack;
    private AccountCtrl theAccountCtrl;
    private JTable theAccountListTable;
    private JScrollPane theScrollPane;
    
    public AccountListView (AccountCtrl theParentAccountCtrl) {
        theAccountCtrl = theParentAccountCtrl;

        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();
        
        label = new JLabel("Your account list:");
        
        theAccountListTable = new JTable(this.theAccountCtrl.getAccountTableModel());
        theAccountListTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        theAccountListTable.getColumnModel().getColumn(1).setPreferredWidth(50);
        theAccountListTable.getColumnModel().getColumn(2).setPreferredWidth(50);
        theScrollPane = new JScrollPane(theAccountListTable);
        theScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        theScrollPane.setPreferredSize(new Dimension(300, 200));
        theAccountListTable.setFillsViewportHeight(true);
        
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnBack = new JButton("Back");
        btnBack.addActionListener(this);
        
        panel.add(label);
        panel2.add(theScrollPane);
        panel3.add(btnBack);
        panel3.add(btnClose);
        
        this.setTitle("Credential Manager");
        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.getContentPane().add(panel, this.getContentPane());
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.setSize(400, 310);
        this.setResizable(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Close")){
            System.exit(0);
        }
        else if(arg.equals("Back")) {
            this.setVisible(false);
            MainMenu main = new MainMenu();
            main.setVisible(true);
        }
    }
}

package credentialmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

//Authenticates users' credentials and any necessary controls for the login menu
public class LoginCtrl {
    private LoginMenu loginMenu;
    private UserList userList;
    static String currentUser;
    
    public LoginCtrl() {
        this.userList = new UserList();
        this.loginMenu = new LoginMenu(this);
    }
    
    public LoginCtrl(int x){
    }

   // public boolean authenticate(String username, char[] password) {
       // boolean authenticated = false;
       // for (int i = 0; i < userList.getListOfUsers().size(); i++) {
            //if (Arrays.equals(userList.getListOfUsers().get(i).getPassword(), password) && userList.getListOfUsers().get(i).getUsername().equalsIgnoreCase(username)){
               // authenticated = true;
            //}
        //}
        public boolean authenticate(String username, char[] password) throws FileNotFoundException, IOException{
            boolean authenticated = false;
            //String convPass = String.valueOf(password);
            String convPass = new String(password);
            String fileName = username+ ".txt";
            File file = new File(fileName);
            
            Scanner reader = new Scanner(file);
            
            ArrayList<String> stockVars = new ArrayList<>();
            ArrayList<String> fileVars = new ArrayList<>();
            
            stockVars.add(username);
            stockVars.add(convPass);
            
            System.out.print(stockVars);
            
            for(int i = 0; i <2; i++) {
                fileVars.add(reader.nextLine());
            }
            System.out.print(fileVars);
             
            if(stockVars.equals(fileVars)){
                authenticated = true;
                currentUser = username;
                System.out.print("[X]");
            }
            
            return authenticated;
        }
    
        static String whosLoggedOn(){         
            return currentUser;
        }
}

package credentialmanager;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class AccountCtrl {
    private AddAccountView addAccountView = null;
    private Account account = null;
    private AccountTableModel theAccountTableModel = null;
    private AccountListView accountListView = null;
    private AccountList theAccountList = null;
    
    public AccountCtrl(AddAccountView addAccountView) {
        theAccountList = new AccountList();
        theAccountTableModel = new AccountTableModel(theAccountList.getListOfAccounts());
        addAccountView = new AddAccountView(this);
        addAccountView.setVisible(true);
    }
    
    public AccountCtrl(AccountListView accountListView) {
        theAccountList = new AccountList();
        theAccountTableModel = new AccountTableModel(theAccountList.getListOfAccounts());
        accountListView = new AccountListView(this);
        accountListView.setVisible(true);
    }

    public void setAccount(Account acct) {
        account = acct;
    }
    
    public AccountTableModel getAccountTableModel() {
        return this.theAccountTableModel;
    }
}
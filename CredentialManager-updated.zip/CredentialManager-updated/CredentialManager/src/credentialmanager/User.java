package credentialmanager;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable{
    private String username = "";
    private char[] password = {};
    
    public User(String newUsername, char[] newPassword) {
        username = newUsername;
        password = newPassword;
    }
    
    public String getUsername() {
        return username;
    }
    
    public char[] getPassword() {
        return password;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

/**
 *
 * @author hmk5180
 */
public class AddAccountView extends JFrame implements ActionListener {
    private JPanel panel1, panel2, panel3, panel4, panel5, panel6, panel7, panel8;
    private JLabel label1, usernameLabel, accountLabel, passwordLabel, rePasswordLabel;
    private JTextField usernameField, accountField;
    private JPasswordField passwordField, rePasswordField;
    private JButton submit, btnClose, btnBack;   
    private AccountCtrl theAccountCtrl = null;
    private AccountTableModel theAccountTableModel = null;
    private AccountList theAccountList = null;
    private JTable theAccountListTable;
    private JScrollPane theScrollPane;
    
    public AddAccountView(AccountCtrl theParentAccountCtrl) {
        theAccountCtrl = theParentAccountCtrl;
        theAccountListTable = new JTable(this.theAccountCtrl.getAccountTableModel());
        theAccountListTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        
        theScrollPane = new JScrollPane(theAccountListTable);
        theScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        theScrollPane.setPreferredSize(new Dimension(350, 200));
        theAccountListTable.setFillsViewportHeight(true);
        
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();
        panel6 = new JPanel();
        panel7 = new JPanel();
        panel8 = new JPanel();
        
        label1 = new JLabel("<Add New Account>");
        
        accountLabel = new JLabel("Account title:");
        accountField = new JTextField();
        
        usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        
        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        
        rePasswordLabel = new JLabel("Re-enter password:");
        rePasswordField = new JPasswordField();
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnBack = new JButton("Back");
        btnBack.addActionListener(this);
        
        accountField.setColumns(16);
        usernameField.setColumns(10);
        passwordField.setColumns(10);
        rePasswordField.setColumns(10);
        
        panel1.add(accountLabel);
        panel1.add(accountField);
        panel2.add(usernameLabel);
        panel2.add(usernameField);
        panel3.add(passwordLabel);
        panel3.add(passwordField);
        panel4.add(rePasswordLabel);
        panel4.add(rePasswordField);
        panel5.add(submit);
        panel5.add(btnBack);
        panel5.add(btnClose);
        panel6.add(label1);
        panel7.add(theScrollPane);
        
        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.getContentPane().add(panel6, this.getContentPane());
        this.getContentPane().add(panel7, this.getContentPane());
        this.getContentPane().add(panel1, this.getContentPane());
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.getContentPane().add(panel4, this.getContentPane());
        this.getContentPane().add(panel5, this.getContentPane());
        this.setSize(400, 450);
        this.setTitle("Credential Manager");
        this.setResizable(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.getRootPane().setDefaultButton(submit);
    }
    
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            if(Arrays.equals(this.passwordField.getPassword(),this.rePasswordField.getPassword()) && !this.accountField.getText().equals("") && !this.usernameField.getText().equals("") && this.passwordField.getPassword().length != 0 && this.rePasswordField.getPassword().length != 0){
                String account = this.accountField.getText();
                String username = this.usernameField.getText();
                char[] password = this.passwordField.getPassword();
                
                theAccountTableModel = (AccountTableModel) theAccountListTable.getModel();
                theAccountTableModel.addRow(new Account(account, username, password));
                
                //this.setVisible(false);
                //MainMenu newMain = new MainMenu();
            }
            else if(!Arrays.equals(this.passwordField.getPassword(),this.rePasswordField.getPassword())){
                JOptionPane.showMessageDialog(null, "Your passwords do not match, try again!");
            }
            else{
                JOptionPane.showMessageDialog(null, "Please fill in all fields!");
            }
        }
        else if(arg.equals("Back")) {
            this.setVisible(false);
            MainMenu main = new MainMenu();
            main.setVisible(true);
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

//GUI for the LoginMenu
public class LoginMenu extends JFrame implements ActionListener{
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JPanel panel6;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel label;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton submit;
    private JButton btnClose;
    
    private LoginCtrl loginCtrl = null;
    
    public LoginMenu(LoginCtrl loginCtrl){
        this.loginCtrl = loginCtrl;

        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();
        panel6 = new JPanel();
        
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        label = new JLabel("Please enter your username and password.");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        passwordField.setActionCommand("");
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        usernameField.setColumns(10);
        passwordField.setColumns(10);
        
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel2.add(passwordLabel);
        panel2.add(passwordField);
        panel3.add(submit);
        panel3.add(btnClose);
        panel4.add(label);
        
        this.getContentPane().add(panel5, this.getContentPane());
        this.getContentPane().add(panel4, this.getContentPane());
        this.getContentPane().add(panel, this.getContentPane());
        this.getContentPane().add(panel2, this.getContentPane());
        this.getContentPane().add(panel3, this.getContentPane());
        this.getContentPane().add(panel6, this.getContentPane());
        this.setSize(300, 230);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.getRootPane().setDefaultButton(submit);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            String username = this.usernameField.getText();
            char[] password = this.passwordField.getPassword();
            try {
                if (this.loginCtrl.authenticate(username, password) && !username.equals("") && !(password==null)) {
                    MainMenu useCaseMenu = new MainMenu();
                    this.setVisible(false);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Incorrect username and/or password. Try again.");
                    LoginCtrl theLoginCtrl = new LoginCtrl();
                }
            } catch (IOException ex) {
                Logger.getLogger(LoginMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

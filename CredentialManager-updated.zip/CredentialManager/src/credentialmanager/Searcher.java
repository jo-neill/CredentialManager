/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author hmk5180
 */
public class Searcher {
    private String result = "";
    private List<Account> listOfAccounts;
    private AccountList accountList;
    private SearcherView sView;
    private boolean found = false;
    
    public Searcher() {
        this.accountList = new AccountList();
        sView = new SearcherView(this);
    }
    
    public String getAccountName(String keyword) {
        int x = accountList.getListOfAccounts().size();
        for (int i = 0; i < x && found == false; i++) {
            if (accountList.getListOfAccounts().get(i).getAccountName().equalsIgnoreCase(keyword)) {
                String accountNameFound = accountList.getListOfAccounts().get(i).getAccountName();
                String usernameFound = accountList.getListOfAccounts().get(i).getUsername();
                char[] passwordFound = accountList.getListOfAccounts().get(i).getPassword();
                String passwordToString = String.valueOf(passwordFound);
                
                result = "Account Name: " + accountNameFound + "\n" + "Username: " + usernameFound + "\n" + "Password: " + passwordToString;

                found = true;
            }
            else {
                result = keyword + " is not found.";
            }
        }
        return result;
    }
}

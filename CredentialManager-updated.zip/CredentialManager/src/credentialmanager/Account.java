package credentialmanager;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Account {   
    private String username = "";
    private char[] password = null;
    private String accountName = "";
    public ArrayList<String> keywords = null;
    
    public Account(String accountName, String username, char[] password){
        this.accountName = accountName;
        this.username = username; 
        this.password = password;
    }
    public String getAccountName(){
        return accountName;
    }

    public String getUsername() {
        return username;
    }

    public char[] getPassword() {
        return password;
    }
}
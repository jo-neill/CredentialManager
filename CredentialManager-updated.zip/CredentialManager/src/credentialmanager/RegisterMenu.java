/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

/**
 *
 * @author Zach
 */
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class RegisterMenu extends JFrame implements ActionListener{
    private final JPanel panel, panel1, panel2, panel3, panel4, panel5;
    private final JLabel label, label1, label2, label3;
    private final JButton btnSubmit, btnClose, btnBack;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    
    public RegisterMenu(){
        this.setLayout(new GridLayout(5, 1));
        
        panel = new JPanel(new FlowLayout());
        panel1 = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        panel5 = new JPanel(new FlowLayout());
        
        label = new JLabel("<Register>");
        label1 = new JLabel("Username:");
        label2 = new JLabel("Password:");
        label3 = new JLabel("Confirm Password:");
        
        usernameField = new JTextField();
        usernameField.setColumns(10);
        passwordField = new JPasswordField();
        passwordField.setColumns(10);
        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setColumns(10);
        
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnBack = new JButton("Back");
        btnBack.addActionListener(this);
        
        panel.add(label);
        panel1.add(label1); 
        panel1.add(usernameField);
        panel2.add(label2); 
        panel2.add(passwordField);
        panel3.add(label3); 
        panel3.add(confirmPasswordField);
        panel4.add(btnSubmit);
        panel4.add(btnBack);
        panel4.add(btnClose);
        
        this.add(panel);
        this.add(panel1);
        this.add(panel2);
        this.add(panel3);
        this.add(panel4);
        this.setTitle("Credential Manager");
        this.setSize(400, 220);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        
        if(arg.equals("Submit")){
            
            String usr = usernameField.getText();
            String pass = passwordField.getText();
            String pass_cfm = confirmPasswordField.getText();
            if(pass.equals(pass_cfm)){
                
                try{
                    RegisterCtrl theRegisterCtrl = new RegisterCtrl(usr, pass);
                    this.setVisible(false);
                    new AppMenu();
                }catch(Exception x){
                    JOptionPane.showMessageDialog(null, "Something went wrong :(");
                }
                
            }
            else{
                JOptionPane.showMessageDialog(null, "Your password and password confirmation do not match!\nPlease try again.");
                this.setVisible(false);
                new RegisterMenu();
            }
        }
        
        else if(arg.equals("Close")){
            System.exit(0);
        }
        
        else if(arg.equals("Back")) {
            this.setVisible(false);
            AppMenu appMenu = new AppMenu();
            appMenu.setVisible(true);
        }
    }
}

package credentialmanager;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

public class AccountCtrl {
    private AddAccountView addAccountView = null;
    private Account account = null;
    private AccountTableModel theAccountTableModel = null;
    private AccountListView accountListView = null;
    private AccountList theAccountList = null;
    
    public AccountCtrl(AddAccountView addAccountView) {
        theAccountList = new AccountList();
        theAccountTableModel = new AccountTableModel(theAccountList.getListOfAccounts());
        addAccountView = new AddAccountView(this);
        addAccountView.setVisible(true);
    }
    
    public AccountCtrl(AccountListView accountListView) {
        theAccountList = new AccountList();
        theAccountTableModel = new AccountTableModel(theAccountList.getListOfAccounts());
        accountListView = new AccountListView(this);
        accountListView.setVisible(true);
    }
    
    public AccountCtrl(String acctName, String username, char[] password) throws FileNotFoundException, UnsupportedEncodingException{
        String fileName = LoginCtrl.whosLoggedOn() + ".txt";
        BufferedWriter bw = null;

      try {
         bw = new BufferedWriter(new FileWriter(fileName, true));
	 bw.newLine();
         bw.write(acctName);
	 bw.newLine();
         bw.write(username);
         bw.newLine();
         String conv = new String(password);
         bw.write(conv);
         bw.newLine();
	 bw.flush();
      } catch (IOException ioe) {
	 ioe.printStackTrace();
      } finally {                    
	 if (bw != null) try {
	    bw.close();
	 } catch (IOException ioe2) {
	    // just ignore it
	 }
      }
    }

    public void setAccount(Account acct) {
        account = acct;
    }
    
    public AccountTableModel getAccountTableModel() {
        return this.theAccountTableModel;
    }
}
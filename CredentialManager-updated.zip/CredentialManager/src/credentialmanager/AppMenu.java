package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//GUI for the main menu
public class AppMenu extends JFrame implements ActionListener{
    private final JPanel panel1, panel2, panel3, panel4;
    private final JLabel label1;
    private final JButton btnOpenLogin, btnClose, btnRegister;

    public AppMenu(){
        this.setLayout(new GridLayout(4,1));
        
        panel1 = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        
        label1 = new JLabel("Welcome to Credential Manager!");
        
        btnOpenLogin = new JButton("Login");
        btnOpenLogin.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        btnRegister = new JButton("Register");
        btnRegister.addActionListener(this);
        
        panel1.add(btnOpenLogin);
        panel1.add(btnRegister);
        panel1.add(btnClose);
        panel3.add(label1);
        
        this.add(panel4);
        this.add(panel3);
        this.add(panel1);
        this.add(panel2);
        this.setTitle("Credential Manager");
        this.setSize(300, 200);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        
        if(arg.equals("Login")){
            LoginCtrl loginCtrl = new LoginCtrl();
            this.setVisible(false);
        }
        
        else if(arg.equals("Register")){
            RegisterMenu reg = new RegisterMenu();
            this.setVisible(false);
        }
        
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
    
}

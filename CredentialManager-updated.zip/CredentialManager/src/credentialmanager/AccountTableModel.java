/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author hmk5180
 */
public class AccountTableModel extends AbstractTableModel {
    private static String[] columnNames = {"Account Name", "Username"};
    private ArrayList<Account> accountTableData = null;
    
    public AccountTableModel(ArrayList<Account> theAccountTableData) {
        this.accountTableData = theAccountTableData;
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }
    
    public int getRowCount() {
        return accountTableData.size();
    }
    
    public String getColumnName(int col) {
        return columnNames[col];
    }
    
    public Object getValueAt(int row, int col) {
        Object objectToReturn = new Object();
        switch(col) {
            case 0: objectToReturn = accountTableData.get(row).getAccountName();break;
            case 1: objectToReturn = accountTableData.get(row).getUsername();break;
        }
        return objectToReturn;
    }
    
    public void addRow(Account newAccount) {
        this.accountTableData.add(newAccount);
        this.fireTableDataChanged();
    }
}

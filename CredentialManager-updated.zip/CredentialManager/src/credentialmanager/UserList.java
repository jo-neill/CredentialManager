package credentialmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;


//UserList creates a List of users
public class UserList {
    private ArrayList<User> listOfUsers;

    public UserList() {
        listOfUsers = new ArrayList();
    }

    public ArrayList<User> getListOfUsers() {
        return listOfUsers;
    }

    public void addUser(User newUser) {
        listOfUsers.add(newUser);
    }
    
    //------------------------------------------------------
    
    void addUserFile(User usr) throws FileNotFoundException, UnsupportedEncodingException{
    
        String fileName = usr.getUsername()+ ".txt";
        
        File f = new File(usr.getUsername()+ ".txt");
        boolean exists = f.exists();
        
        if(!exists){
        try (PrintWriter writer = new PrintWriter(fileName, "UTF-8")) {
            writer.println(usr.getUsername());
            writer.println(String.valueOf(usr.getPassword()));
            writer.close();
        }
        }
        else{
            JOptionPane.showMessageDialog(null, "That username already exists. Please try again.");
        }
    }
}

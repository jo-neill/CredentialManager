package credentialmanager;

import java.util.ArrayList;

public class AccountList {
    private ArrayList<Account> listOfAccounts;
    
    public AccountList(ArrayList<Account> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }
    
    public AccountList() {
        listOfAccounts = new ArrayList();
        createTestAccounts();
    }
    
    private void createTestAccounts() {
        char[] testPassword = {'p', 'a', 's', 's'};
        addAccount(new Account("gmail", "hyunsook@gmail.com", testPassword));
        addAccount(new Account("canvas", "nate@psu.edu", testPassword));
        addAccount(new Account("youtube", "zach@gmail.com", testPassword));
        addAccount(new Account("pnc", "joe123", testPassword));
        addAccount(new Account("att", "hyun123", testPassword));
        addAccount(new Account("yahoo", "hsook", testPassword));
        addAccount(new Account("hotmail", "joe@hotmail.com", testPassword));
    }
    
    public void addAccount(Account newAccount){
        listOfAccounts.add(newAccount);
    }
    
    public ArrayList<Account> getListOfAccounts() {
        return listOfAccounts;
    }
}
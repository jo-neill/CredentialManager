/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author Zach
 */
public class RegisterCtrl extends UserList{

    public RegisterCtrl(String username, String password) throws FileNotFoundException, UnsupportedEncodingException {
        char[] passArray = new char[password.length()];
        
        for(int i = 0; i < password.length(); i++){
            passArray[i] = password.charAt(i);
        }

        User usr = new User(username, passArray);
        super.addUserFile(usr);
    }     
}

package credentialmanager;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

//GUI for the LoginMenu
public class LoginMenu extends JFrame implements ActionListener{
    private JFrame frame;
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JPanel panel6;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel label;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton submit;
    private JButton btnClose;
    
    private LoginCtrl loginCtrl = null;
    
    public LoginMenu(LoginCtrl loginCtrl){
        this.loginCtrl = loginCtrl;
        
        frame = new JFrame("Credential Manager");
        frame.setLayout(new GridLayout(6,1));
        panel = new JPanel(new FlowLayout());
        panel2 = new JPanel(new FlowLayout());
        panel3 = new JPanel(new FlowLayout());
        panel4 = new JPanel(new FlowLayout());
        panel5 = new JPanel(new FlowLayout());
        panel6 = new JPanel(new FlowLayout());
        
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        label = new JLabel("Please enter your username and password.");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        passwordField.setActionCommand("");
        
        submit = new JButton("Submit");
        submit.addActionListener(this);
        btnClose = new JButton("Close");
        btnClose.addActionListener(this);
        
        usernameField.setColumns(10);
        passwordField.setColumns(10);
        
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel2.add(passwordLabel);
        panel2.add(passwordField);
        panel3.add(submit);
        panel3.add(btnClose);
        panel4.add(label);
        
        frame.add(panel5);
        frame.add(panel4);
        frame.add(panel);
        frame.add(panel2);
        frame.add(panel3);
        frame.add(panel6);
        frame.setSize(300, 230);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.getRootPane().setDefaultButton(submit);
    }
    
    public JFrame getFrame() {
        return frame;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String arg = e.getActionCommand();
        if(arg.equals("Submit")){
            String username = this.usernameField.getText();
            char[] password = this.passwordField.getPassword();
            if (this.loginCtrl.authenticate(username, password) && !username.equals(null) && !(password==null)) {
                MainMenu useCaseMenu = new MainMenu();
                this.frame.setVisible(false);
            }
            else {
                JOptionPane.showMessageDialog(null, "Incorrect username and/or password. Try again.");
                LoginCtrl theLoginCtrl = new LoginCtrl();
            }
        }
        else if(arg.equals("Close")){
            System.exit(0);
        }
    }
}

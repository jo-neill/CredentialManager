/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;
/**
 *
 * @author Zach
 */
public class RegisterCtrl {

    public RegisterCtrl() {
        new RegisterMenu();
    }

    public void addUser(String username, String password) {
       
        User usr = new User(username, password.toCharArray());
        UserList.addUser(usr);
        
        }
        
}

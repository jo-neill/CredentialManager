package credentialmanager;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class Account implements Serializable{
    
    private final String username;
    private char[] password;
    private String accountName;
    public List<String> keywords;
    private boolean isEncrypted;
    
    public Account(String accountName, String username, char[] password){
        this.accountName = accountName;
        this.username = username; 
        this.password = password;
        this.isEncrypted = false;
    }
    public String getAccountName(){
        return accountName;
    }
    public void addPassword(char[] newPassword){
    
        if(getPassword()==null){
            password = newPassword;
        }
        
    }
    
    public void changePassword(char[] newPassword){
    
        if(isEncrypted == false && !(password==null)){
            password = newPassword;
        }    
    }
    
    @Override
    public String toString(){
        return "Account: " + accountName + "\n" + "Username: " + username + "\n" + "Password: " + password.toString();
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        String pass = new String(password);
        return pass;
    }
    
    
    
}
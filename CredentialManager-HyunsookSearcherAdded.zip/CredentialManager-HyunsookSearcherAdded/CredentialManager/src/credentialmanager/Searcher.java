/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.List;

/**
 *
 * @author hmk5180
 */
public class Searcher {
    private String result = "";
    private List<Account> listOfAccounts;
    private AccountList accountList;
    private SearcherView sView;
    private boolean found = false;
    
    public Searcher() {
        this.accountList = new AccountList();
        sView = new SearcherView(this);
    }
    
    public String getAccountName(String keyword) {
        int x = accountList.getListOfAccounts().size();
        for (int i = 0; i < x && found == false; i++) {
            if (accountList.getListOfAccounts().get(i).getAccountName().equalsIgnoreCase(keyword)) {
                result = accountList.getListOfAccounts().get(i).toString();
                found = true;
            }
            else {
                result = keyword + " is not found.";
            }
        }
        return result;
    }
}

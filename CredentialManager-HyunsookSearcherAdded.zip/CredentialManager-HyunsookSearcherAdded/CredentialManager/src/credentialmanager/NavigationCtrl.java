package credentialmanager;

//Cotrols the navigation of the program
public class NavigationCtrl {
    public NavigationCtrl() {
        // App is set to terminate for now but will eventually navigate users to somewhere else
        System.exit(0);
    }
}

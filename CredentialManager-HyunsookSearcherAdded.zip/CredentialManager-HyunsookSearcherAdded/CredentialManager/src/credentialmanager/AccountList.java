/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hmk5180
 */
public class AccountList {
    private List<Account> listOfAccounts;
    
    public AccountList(ArrayList<Account> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }
    
    public AccountList() {
        listOfAccounts = new ArrayList();
        createTestAccounts();
    }
    
    private void createTestAccounts() {
        char[] testPassword = {'p', 'a', 's', 's'};
        addAccount(new Account("gmail", "hyunsook@gmail.com", testPassword));
        addAccount(new Account("canvas", "hyunsook@psu.edu", testPassword));
        addAccount(new Account("youtube", "hyunsook12@gmail.com", testPassword));
    }
    
    public void addAccount(Account newAccount){
        listOfAccounts.add(newAccount);
    }
    
    public List<Account> getListOfAccounts() {
        return listOfAccounts;
    }
}

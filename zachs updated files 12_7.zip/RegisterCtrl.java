/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package credentialmanager;
/**
 *
 * @author Zach
 */
public class RegisterCtrl extends UserList{

    public RegisterCtrl(String username, String password) {
        addNewUser(username, password);
    }

    public void addNewUser(String username, String password) {
        char[] passArray = new char[password.length()];
        
        for(int i = 0; i < password.length(); i++){
            passArray[i] = password.charAt(i);
        }

        User usr = new User(username, passArray);
        addUser(usr);
        
        }
        
}
